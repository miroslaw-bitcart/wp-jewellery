<?php get_header(); ?>

<div class="heading <?php if(is_shop()) { echo "search";} ?>">
    <?php
        if(is_shop()) { 
            if( $_GET['s'] != '')
                echo '<h3>Search results: <em>'.get_search_query().'</em></h3>';
            else
                echo '<h1>Shop</h1>';
        } else {
            echo '<h1 data-bind=text: allTitle()></h1>';
        }
    ?>
</div>

<div class="sort-bar clearfix">
    <a class="filter-toggle" data-toggle="collapse" data-target=".sidebar-filter">Show Filter <span class="ion-ios-settings-strong"></span></a>
    <?php woocommerce_catalog_ordering();?> 
    <?php woocommerce_result_count();?>
</div>

<div class="relative left">

    <?php hm_get_template_part( 'sidebar-shop' ); ?>

    <div class="content grid-container shop">

        <ul>
            <?php if ( have_posts() ) : ?>
                <?php while ( have_posts() ) : the_post(); ?>
                    <li class="grid-product">
                    <?php hm_get_template_part( 'products/grid-product', array( 'quick_view' => true, 'flip_on_hover' => true ) ); ?>
                    </li>
                <?php endwhile; ?>
            <?php endif; ?> 

            <?php
                if( $_GET['s'] != '')
                echo '
                    <li class="enquiry">
                    <h3>Looking for<br>something specific?</h3>
                    <p>Tell us and we\'ll find it for you</p>
                    <a href="/contact" class="silver button block">Contact</a>
                    </li>
                ';
            ?>
        </ul>

        <p class="centered clearfix" data-bind="visible: ready() && !products().length, html: 'Sorry, there are no items matching your criteria'"></p>

        <?php woocommerce_pagination();?>

    </div>

</div>

<!--
<div class="modal fade" id="product" tabindex="-1" role="dialog" aria-labelledby="productLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
    </div>
    </div>
</div>
-->

<?php get_footer(); ?>