<?php get_header(); ?>	

<div class="home panel hero clearfix">

	<a href="<?php echo esc_url( home_url( '/collection/christmas-gifts' ) ); ?>">
		<div class="caption">
			<h1>Let It Glow</h1>
			<span class="action hvr-grow inverse">Shop Christmas Gifts</span>
			<p>
				<?php $count_posts = wp_count_posts('product'); echo $count_posts->publish; ?> one-of-a-kind items - updated daily<br>
				Free Delivery, Returns &amp; Ring Sizing
			</p>
		</div>
	</a>

</div>

<div class="grid-container clearfix">

	<div class="home panel subs col-2">
		<a class="latest-finds inverse" href="<?php echo esc_url( home_url( '/latest-finds/' ) ); ?>">
			<h1 class="impact"><?php wp_posts_in_days('days=30'); ?></h1>
			<h2>Discoveries this Month</h2>
			<span class="action hvr-grow inverse">Shop Latest Finds</span>
		</a>
	</div>

	<div class="home panel subs col-2">
		<a class="engagement-rings" href="<?php echo esc_url( home_url( '/engagement-rings/' ) ); ?>">
			<h1 class="impact">1,276</h1>
			<h2>Proposals and Counting...</h2>
			<span class="action hvr-grow">Shop Engagement Rings</span>
		</a>
	</div>

	<div class="home panel subs col-2">
		<a class="hot-100 inverse" href="<?php echo esc_url( home_url( '/trending/' ) ); ?>">
			<h1>The Hot<br>1OO</h1>
			<span class="action hvr-grow inverse">Our Most Desired Items</span>
		</a>
	</div>

	<div class="home panel subs col-2">
		<a class="lookbooks inverse" href="<?php echo esc_url( home_url( '/lookbooks/' ) ); ?>">
			<h1>Get the<br>Look</h1>
			<span class="action hvr-grow inverse">View Our Lookbooks</span>
		</a>
	</div>

</div>

<div class="home panel as-seen-in indent clearfix">
	<h4 class="subheading space-below">As Seen In</h4>
	<div class="wrapper clearfix">
		<a href="<?php echo site_url( '/press' ); ?>">
			<img src="<?php bloginfo('template_directory'); ?>/assets/images/front-page/featured-press-1.png" alt="Antique Jewellery Company Press" width="512" height="27" class="logos">
			<img src="<?php bloginfo('template_directory'); ?>/assets/images/front-page/featured-press-2.png" alt="Antique Jewellery Company Press" width="512" height="26" class="logos">
		</a>
	</div>
</div>

<!--
<svg version="1.1" id="loader-1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
width="80px" height="80px" viewBox="0 0 40 40" enable-background="new 0 0 40 40" xml:space="preserve">
<path opacity="0.2" fill="#000" d="M20.201,5.169c-8.254,0-14.946,6.692-14.946,14.946c0,8.255,6.692,14.946,14.946,14.946
s14.946-6.691,14.946-14.946C35.146,11.861,28.455,5.169,20.201,5.169z M20.201,31.749c-6.425,0-11.634-5.208-11.634-11.634
c0-6.425,5.209-11.634,11.634-11.634c6.425,0,11.633,5.209,11.633,11.634C31.834,26.541,26.626,31.749,20.201,31.749z"/>
<path fill="#000" d="M26.013,10.047l1.654-2.866c-2.198-1.272-4.743-2.012-7.466-2.012h0v3.312h0
C22.32,8.481,24.301,9.057,26.013,10.047z">
<animateTransform attributeType="xml"
	attributeName="transform"
	type="rotate"
	from="0 20 20"
	to="360 20 20"
	dur="0.5s"
	repeatCount="indefinite"/>
</path>
</svg>
-->

<div class="home panel slider indent clearfix">
	<h4 class="subheading space-below">Just Added</h4>
	<div class="flexslider products">
		<ul class="slides">

			<?php
			$args = array(
			'post_type' => 'product',
			'posts_per_page' => 24,
			'orderby' =>'random',
			'flip_on_hover' => true
			);

			$loop = new WP_Query( $args );

			while ( $loop->have_posts() ) : $loop->the_post(); 
			global $product; ?>

			<li>
				<a href="<?php the_permalink(); ?>">
					<?php 
					$image_title = esc_attr( get_the_title( get_post_thumbnail_id() ) );
		    		$attachment_ids = $product->get_gallery_attachment_ids();
		    		$default_img =  wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), 'grid-larger');
		    		$attchimage_finalNum = count($attachment_ids) - 1;
		    		$mouserover_img = wp_get_attachment_image_src($attachment_ids[$attchimage_finalNum], 'grid-larger');
		      		//echo $image; 
			      	?>
			    	<img src="<?php echo $default_img[0];?>" alt="<?php the_title(); ?>" onmouseover="this.src='<?php echo $mouserover_img[0];?>'" onmouseout="this.src='<?php echo $default_img[0];?>'" />
					<h3><?php the_title(); ?></h3>
					<?php echo $product->get_price_html(); ?>
				</a>
			</li>
			<?php endwhile; ?>
		</ul>
	</div>
</div>

<div class="home panel reviews indent clearfix">
	<img class="centered" src="<?php bloginfo('template_directory'); ?>/assets/images/front-page/google.png" alt="Google Ratings" width="110" height="37">
	<div class="stars block">
		4.9
		<span class="small-space-left ion-star"></span>
		<span class="ion-star"></span>
		<span class="ion-star"></span>
		<span class="ion-star"></span>
		<span class="small-space-right ion-star"></span>
		<a href="https://goo.gl/9uPy3b" target="_blank">View All</a>
	</div>
	<div class="flexslider reviews">
		<ul class="slides">
			<li class="carousel-item active">
				<p>We visited The AJC to buy an engagement ring. Can't say enough about the amazing service we received. They have the most exquisite selection of jewellery and really take the time to help you decide. I would strongly recommend a visit.</p>
				<small class="subheading">&mdash; Jane, London</small>
			</li>

			<li class="carousel-item">
				<p>Olly was so lovely and helpful, which is exactly what you need when you're buying an engagement ring.</p>
				<small class="subheading">&mdash; Grant, Brooklyn, New York</small>
			</li>

			<li class="carousel-item">
				<p>Service was unbeatable - worked to an extremely tight time scale and delivered without a hitch. The ring is perfect and I'm proud to see it on the hand of my fiancé. You guys have made us both very happy!</p>
				<small class="subheading">&mdash; Oscar Barrett, Kent, UK</small>
			</li>

			<li class="carousel-item">
				<p>I live in the United States, and working with the AJC was easier than going into a store here! They were easily accessible and we even did a video Skype session for additional looks. They had the ring sized and out and shipped to the USA by the next day. Simply an amazing customer experience!</p>
				<small class="subheading">&mdash; Ben, Atlanta, USA</small>
			</li>
			
			<li class="carousel-item">
				<p>Excellent service - very personal, engaged and attentive. From advice on the provenance and suitability of the rings I had chosen, from a very well presented web site, to ensuring that they arrived on time  - faultless!</p>
				<small class="subheading">&mdash; Edward, Wiltshire, UK</small>
			</li>
			
			<li class="carousel-item">
				<p>Excellent experience from start to finish, I didn't have a clue what I was doing when looking at engagement rings but was very happy with my purchase. And it seemed to do the trick as she happily said yes!</p>
				<small class="subheading">&mdash; Matt, London</small>
			</li>
		</ul>
	</div>
</div>

<div class="home panel instagram clearfix">

	<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/assets/javascripts/lib/instafeed.min.js"></script>
	
	<span class="hvr-grow"><a target="_blank" href="http://www.instagram.com/antiquejewellerycompany">@antiquejewellerycompany</a></span>

	<div id="instafeed"></div>

	<script type="text/javascript">
	  var userFeed = new Instafeed({
	    get: 'user',
	    userId: '977280213',
	    clientId: '97865ae64a444040b6b5aa7545a243f4',
	    accessToken: '977280213.97865ae.49cfe81669064d18906d935f07922bf4',
	    resolution: 'standard_resolution',
	    template: '<a class="col-6" href="{{link}}" target="_blank" id="{{id}}"><img src="{{image}}" /></a>',
	    sortBy: 'most-recent',
	    limit: 6,
	    links: false
	  });
	  userFeed.run();
	</script>

</div>

<?php get_footer(); ?>