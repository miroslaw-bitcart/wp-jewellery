<?php get_header(); ?>

	<aside class="static" data-spy="affix" data-offset-top="190" data-offset-bottom="600"><?php get_sidebar( "discover" ); ?></aside>

	<div class="content a-z static">

		<div class="left-col">
			<h2>Almanac</h2>
		</div>

		<div class="right-col"><h3>Coming soon...</h3></div>

	</div>

<?php get_footer(); ?>