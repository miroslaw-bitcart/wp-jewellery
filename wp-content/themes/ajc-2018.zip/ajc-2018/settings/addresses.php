<div class="content">
	<div class="taxonomy-header centered border-bottom"><h2>My Addresses</h2></div>
	<p class="myaccount_address centered space-above space-below"><?php _e('The following addresses will be used on the checkout page by default', 'woocommerce'); ?></p>
	<?php woocommerce_get_template('myaccount/my-address.php'); ?>
</div>