<?php get_header(); ?>
<div class="heading hot-100">
	<h1><span style="font-size:18px;line-height:30px;display:block;">The</span><span style="font-size:54px;line-height:27px;">Hot</span><br><span style="font-size:67px;line-height:54px;display:block;">1OO</span></h1>
    <ul class="after">
        <li>Most Desired Items</li>
    </ul>   
</div>
<div class="content shop full-width new-arrivals">

    <?php dynamic_sidebar( 'primary' ); ?>

</div>

<?php get_footer(); ?>				