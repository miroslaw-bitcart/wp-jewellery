<div class="welcome modal centered padded">
	<img src="<?php bloginfo('template_directory'); ?>/images/bertie.jpg" alt="Bertie" style="width: auto;">
	<h1>Welcome to The Antique Jewellery Company</h1><hr>
	<h2>The home of Antique Jewellery on the web.</h2>
</div>