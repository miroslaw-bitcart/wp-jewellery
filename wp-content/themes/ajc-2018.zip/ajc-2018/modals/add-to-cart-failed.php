<?php $failure = $template_args['failure']; ?>
<?php echo $failure; ?>