<div class="modal fade video" id="video" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-body">
                <div class="video-container">
                    <iframe width="640" height="360" src="https://www.youtube.com/embed/bJUrFqE3rak" frameborder="0" allowfullscreen></iframe>
                </div>
            </div>
        </div>
    </div>
</div>