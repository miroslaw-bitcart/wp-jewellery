<footer class="mobile clearfix">
	<p><span>Contact us:</span><br>+44 (0)20 7206 2477</p>
	<p>Free Shipping Worldwide on all orders</p>
	<a href="http://www.facebook.com/antiquejewellerycompany" target="_blank"><span class="icon-facebook"></span></a>
	<a href="http://www.pinterest.com/antiquejewels" target="_blank"><span class="icon-pinterest"></span></a>
	<a href="http://www.twitter.com/ajc_london" target="_blank"><span class="icon-twitter"></span></a>
</footer>