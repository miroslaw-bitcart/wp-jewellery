<aside class="shop sidebar-filter collapse in">

	<a class="item main" data-toggle="collapse" href="#price" role="button" aria-expanded="false" aria-controls="price">Price</a>
	<div class="collapse" id="price">
		<a>Price Slider</a>
	</div>

	<a class="item main" data-toggle="collapse" href="#type" role="button" aria-expanded="false" aria-controls="type">Type</a>
	<div class="collapse" id="type">
		<a><input type="checkbox"/><label>Rings</label></a>
		<a><input type="checkbox"/><label>Earrings</label></a>
		<a><input type="checkbox"/><label>Brooches</label></a>
		<a><input type="checkbox"/><label>Lockets &amp; Pendants</label></a>
		<a><input type="checkbox"/><label>Necklaces</label></a>
		<a><input type="checkbox"/><label>Seals &amp; Signet Rings</label></a>
		<a><input type="checkbox"/><label>Bracelets &amp; Bangles</label></a>
		<a><input type="checkbox"/><label>Charms</label></a>
		<a><input type="checkbox"/><label>Chains</label></a>
		<a><input type="checkbox"/><label>Curiosities</label></a>
		<a><input type="checkbox"/><label>Men's Jewellery</label></a>
	</div>

	<a class="item main" data-toggle="collapse" href="#age" role="button" aria-expanded="false" aria-controls="age">Age</a>
	<div class="collapse" id="age">
		<a><input type="checkbox"/><label>Georgian</label></a>
		<a><input type="checkbox"/><label>Victorian</label></a>
		<a><input type="checkbox"/><label>Edwardian</label></a>
		<a><input type="checkbox"/><label>Art Nouveau</label></a>
		<a><input type="checkbox"/><label>Art Deco</label></a>
		<a><input type="checkbox"/><label>Retro</label></a>
		<a><input type="checkbox"/><label>Mid-Century</label></a>
		<a><input type="checkbox"/><label>Modern</label></a>
	</div>

	<a class="item main" data-toggle="collapse" href="#gemstone" role="button" aria-expanded="false" aria-controls="gemstone">Gemstone</a>
	<div class="collapse" id="gemstone">
		<a><input type="checkbox"/><label>Diamond</label></a>
		<a><input type="checkbox"/><label>Sapphire</label></a>
		<a><input type="checkbox"/><label>Emerald</label></a>
		<a><input type="checkbox"/><label>Ruby</label></a>
	</div>

	<a class="item main" data-toggle="collapse" href="#metal" role="button" aria-expanded="false" aria-controls="metal">Metal</a>
	<div class="collapse" id="metal">
		<a><input type="checkbox"/><label>Gold</label></a>
		<a><input type="checkbox"/><label>Silver</label></a>
		<a><input type="checkbox"/><label>Platinum</label></a>
		<a><input type="checkbox"/><label>Iron &amp; Cut Steel</label></a>
	</div>


	<a class="item main" data-toggle="collapse" href="#semi-precious" role="button" aria-expanded="false" aria-controls="semi-precious">Semi-Precious Stones</a>
	<div class="collapse" id="semi-precious">
		<a><input type="checkbox"/><label>Agate</label></a>
		<a><input type="checkbox"/><label>Amber</label></a>
		<a><input type="checkbox"/><label>Amazonite</label></a>
		<a><input type="checkbox"/><label>Amethyst</label></a>
		<a><input type="checkbox"/><label>Aquamarine</label></a>
		<a><input type="checkbox"/><label>Black Opal</label></a>
		<a><input type="checkbox"/><label>Bloodstone</label></a>
		<a><input type="checkbox"/><label>Carnelian</label></a>
		<a><input type="checkbox"/><label>Chalcedony</label></a>
		<a><input type="checkbox"/><label>Chrysoberyl</label></a>
		<a><input type="checkbox"/><label>Chrysolite</label></a>
		<a><input type="checkbox"/><label>Chrysoprase</label></a>
		<a><input type="checkbox"/><label>Citrine</label></a>
		<a><input type="checkbox"/><label>Fire Opal</label></a>
		<a><input type="checkbox"/><label>Green Garnet</label></a>
		<a><input type="checkbox"/><label>Garnet</label></a>
		<a><input type="checkbox"/><label>Jade</label></a>
		<a><input type="checkbox"/><label>Jasper</label></a>
		<a><input type="checkbox"/><label>Jet</label></a>
		<a><input type="checkbox"/><label>Kunzite</label></a>
		<a><input type="checkbox"/><label>Labradorite</label></a>
		<a><input type="checkbox"/><label>Lapis Lazuli</label></a>
		<a><input type="checkbox"/><label>Lava</label></a>
		<a><input type="checkbox"/><label>Malachite</label></a>
		<a><input type="checkbox"/><label>Marcasite</label></a>
		<a><input type="checkbox"/><label>Moonstone</label></a>
		<a><input type="checkbox"/><label>Morganite</label></a>
		<a><input type="checkbox"/><label>Nephrite</label></a>
		<a><input type="checkbox"/><label>Onyx</label></a>
		<a><input type="checkbox"/><label>Opal</label></a>
		<a><input type="checkbox"/><label>Peridot</label></a>
		<a><input type="checkbox"/><label>Quartz</label></a>
		<a><input type="checkbox"/><label>Rock Crystal</label></a>
		<a><input type="checkbox"/><label>Rose Quartz</label></a>
		<a><input type="checkbox"/><label>Smokey Quartz</label></a>
		<a><input type="checkbox"/><label>Tanzanite</label></a>
		<a><input type="checkbox"/><label>Topaz</label></a>
		<a><input type="checkbox"/><label>Tourmaline</label></a>
		<a><input type="checkbox"/><label>Turquoise</label></a>
		<a><input type="checkbox"/><label>Zircon</label></a>
	</div>

	<a class="item main" data-toggle="collapse" href="#other" role="button" aria-expanded="false" aria-controls="other">Other</a>
	<div class="collapse" id="other">
		<a><input type="checkbox"/><label>Tortoiseshell</label></a>
		<a><input type="checkbox"/><label>Hair</label></a>
		<a><input type="checkbox"/><label>Ivory</label></a>
		<a><input type="checkbox"/><label>Bakelite</label></a>
		<a><input type="checkbox"/><label>Coral</label></a>
		<a><input type="checkbox"/><label>Enamel</label></a>
		<a><input type="checkbox"/><label>Haematite</label></a>
		<a><input type="checkbox"/><label>Horn</label></a>
		<a><input type="checkbox"/><label>Paste</label></a>
		<a><input type="checkbox"/><label>Pearl</label></a>
		<a><input type="checkbox"/><label>Pinchbeck</label></a>
		<a><input type="checkbox"/><label>Shell</label></a>
		<a><input type="checkbox"/><label>Vauxhall Glass</label></a>
		<a><input type="checkbox"/><label>Vulcanite</label></a>
	</div>

	<a class="item main" data-toggle="collapse" href="#collections" role="button" aria-expanded="false" aria-controls="other">Collections</a>
	<div class="collapse" id="collections">
		<a><input type="checkbox"/><label>Olly's Picks</label></a>
		<a><input type="checkbox"/><label>Christmas Gifts</label></a>
		<a><input type="checkbox"/><label>I ♥ You</label></a>
		<a><input type="checkbox"/><label>Bridal</label></a>
		<a><input type="checkbox"/><label>Forget Me Not</label></a>
		<a><input type="checkbox"/><label>Wonder Room</label></a>
		<a><input type="checkbox"/><label>The Classics</label></a>
		<a><input type="checkbox"/><label>Dandy Man</label></a>
		<a><input type="checkbox"/><label>Macabre</label></a>
		<a><input type="checkbox"/><label>Tiny Feet</label></a>
		<a><input type="checkbox"/><label>Champagne!</label></a>
		<a><input type="checkbox"/><label>Bertie Presents...</label></a>
		<a><input type="checkbox"/><label>Swinging Sporrans</label></a>
		<a><input type="checkbox"/><label>Suffragette</label></a>
		<a><input type="checkbox"/><label>Theodor Fahrner</label></a>
		<a><input type="checkbox"/><label>Decodence</label></a>
		<a><input type="checkbox"/><label>Easter Gifts</label></a>
	</div>

	<a class="item main" data-toggle="collapse" href="#status" role="button" aria-expanded="false" aria-controls="status">Item Status</a>
	<div class="collapse" id="status">
		<a><input type="checkbox"/><label>Sold</label></a>
		<a><input type="checkbox"/><label>On Hold</label></a>
	</div>

	<div class="advert" data-spy="affix" data-offset-top="3500" data-offset-bottom="400">
		<h4>Need help?</h4>
		<h3>+44 (0)20 7206 2477</h3>
		<a href="mailto:enquiries@antiquejewellerycompany.com">&mdash; Email Us</a>
		<a href="<?php echo esc_url( home_url( '/visit-us' ) ); ?>">&mdash;  Visit Us</a>
	</div>

</aside>